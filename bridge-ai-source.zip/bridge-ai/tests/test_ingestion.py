import csv
import io
import json
import os
import zipfile
from pathlib import Path
import pytest
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from backend import db
from scripts.ingest_nbi import classify, rows, coordinate, REQUIRED, ingest


@pytest.mark.parametrize(
    "values,label",
    [
        (["7", "8", "7", "N"], "Good"),
        (["5", "6", "7", "N"], "Fair"),
        (["4", "7", "7", "N"], "Poor"),
        (["N", "N", "N", "3"], "Poor"),
        (["0", "7", "7", "N"], "Poor"),
        (["N"] * 4, None),
        (["", "7", "7", "N"], None),
        (["X", "7", "7", "N"], None),
    ],
)
def test_condition(values, label):
    assert classify(values) == label


def test_official_row_fixture(tmp_path):
    # Real first row from AK25.txt; this small public-data excerpt is not a synthetic bridge.
    source = Path("tests/fixtures/official-ak-2025.csv")
    z = tmp_path / "source.zip"
    with zipfile.ZipFile(z, "w") as archive:
        archive.write(source, "AK25.txt")
    r, member, line = next(rows(z))
    assert r["STRUCTURE_NUMBER_008"] == "0176"
    assert r["MAX_SPAN_LEN_MT_048"] == "43.3"
    assert r["FACILITY_CARRIED_007"] == "FERRY SHUTTLE RTE"
    assert (
        classify(
            [r[k] for k in ["DECK_COND_058", "SUPERSTRUCTURE_COND_059", "SUBSTRUCTURE_COND_060", "CULVERT_COND_062"]]
        )
        == "Fair"
    )
    assert coordinate(r["LAT_016"]) == pytest.approx(55 + 21 / 60 + 23.67 / 3600)
    with pytest.raises(ValueError, match="Insufficient real"):
        ingest(z, db.connect(f"sqlite:///{tmp_path}/small.db"))


def test_bad_schema_fails(tmp_path):
    z = tmp_path / "bad.zip"
    with zipfile.ZipFile(z, "w") as archive:
        archive.writestr("bad.txt", "STATE,ID\n1,2\n")
    with pytest.raises(ValueError, match="missing verified FHWA"):
        list(rows(z))


def test_quoted_comma(tmp_path):
    # Synthetic serialization fixture only; never imported as historical data.
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=sorted(REQUIRED), quotechar="'")
    writer.writeheader()
    writer.writerow({k: ("bridge, quoted" if k == "STRUCTURE_NUMBER_008" else "1") for k in REQUIRED})
    z = tmp_path / "quoted.zip"
    with zipfile.ZipFile(z, "w") as archive:
        archive.writestr("test.txt", stream.getvalue())
    assert next(rows(z))[0]["STRUCTURE_NUMBER_008"] == "bridge, quoted"


def test_constraints(tmp_path):
    engine = db.connect(f"sqlite:///{tmp_path}/constraints.db")
    with pytest.raises(IntegrityError), engine.begin() as c:
        c.execute(
            db.bridges.insert().values(
                id="TEST", state="00", structure_number="TEST", condition="Poor", source_id="missing"
            )
        )
    with engine.begin() as c:
        assert c.execute(select(func.count()).select_from(db.migrations)).scalar() == 1
    db.connect(f"sqlite:///{tmp_path}/constraints.db")


@pytest.mark.real_data
def test_real_counts_provenance():
    if not os.getenv("BRIDGE_REAL_DATA_TEST"):
        pytest.skip("Set BRIDGE_REAL_DATA_TEST=1 after real ingestion")
    engine = db.connect()
    with engine.connect() as c:
        assert dict(c.execute(select(db.bridges.c.condition, func.count()).group_by(db.bridges.c.condition)).all()) == {
            "Poor": 10000,
            "Fair": 5000,
            "Good": 5000,
        }
        assert c.execute(select(func.count()).select_from(db.samples)).scalar() == 20000
        assert c.execute(select(func.count()).select_from(db.inspections)).scalar() == 20000
        source = c.execute(select(db.provenance)).mappings().one()
        details = json.loads(source["details"])
        assert details["source_rows"] >= 624193
        assert len(source["sha256"]) == 64 and source["vintage"] == 2025
        assert details["population"]["Poor"] >= 10000
