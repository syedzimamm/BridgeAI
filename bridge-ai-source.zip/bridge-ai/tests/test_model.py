import json
import os
import pytest
from ml.features import FEATURES, validate_features
from ml.evaluate import evaluate
from backend.inference import score
from backend.db import DATA


def test_feature_alignment_and_leakage():
    assert FEATURES == ["age", "length_m", "width_m", "max_span_m", "adt", "spans", "material", "design"]
    for field in ["deck", "condition", "label", "superstructure", "culvert", "operating_rating"]:
        with pytest.raises(ValueError, match="prohibited"):
            validate_features({field: 4}, "m")
    result = validate_features({"length_m": "12", "design": "2"}, "m")
    assert result["length_m"] == 12 and result["age"] is None and result["design"] == "02"
    assert score(result, True, "existing_2025")["state"] == "Insufficient information"


@pytest.mark.parametrize(
    "values,units",
    [({"length_m": -1}, "m"), ({"adt": "nan"}, "m"), ({"age": "inf"}, "m"), ({"spans": 0}, "m"), ({}, "ft")],
)
def test_invalid_values(values, units):
    with pytest.raises(ValueError):
        validate_features(values, units)


def test_no_information():
    assert score({}, False, "unknown")["state"] == "Insufficient information"
    values = validate_features(
        dict(age=50, length_m=30, width_m=10, max_span_m=15, adt=100, spans=2, material="3", design="02"), "m"
    )
    assert score(values, True, "proposed")["state"] == "Unsupported input"


def test_metrics():
    metrics = evaluate([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9])
    assert metrics["f1"] == 1 and metrics["pr_auc"] == 1
    assert metrics["confusion_matrix"] == [[2, 0], [0, 2]]


@pytest.mark.model
def test_saved_model():
    if not os.getenv("BRIDGE_REAL_DATA_TEST"):
        pytest.skip("Train real model and set BRIDGE_REAL_DATA_TEST=1")
    meta = json.loads((DATA / "model/metrics.json").read_text())
    splits = json.loads((DATA / "model/splits.json").read_text())
    all_ids = [i for group in splits.values() for i in group]
    assert len(all_ids) == len(set(all_ids)) == 20000
    assert meta["features"] == FEATURES
    values = validate_features(
        dict(age=50, length_m=30, width_m=10, max_span_m=15, adt=100, spans=2, material="3", design="02"), "m"
    )
    assert 0 <= score(values, True, "existing_2025")["probability"] <= 1
    values["length_m"] = 1e10
    assert score(values, True, "existing_2025")["state"] == "Unsupported input"
