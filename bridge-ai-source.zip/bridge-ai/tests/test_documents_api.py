import io
import pymupdf as fitz
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from backend import main, db
from backend.documents import canonical_pdf, inspect, MAX_BYTES
from scripts.create_sample_plan import make_sample


@pytest.fixture
def client(tmp_path, monkeypatch):
    engine = db.connect(f"sqlite:///{tmp_path}/test.db")
    monkeypatch.setattr(main, "engine", engine)
    monkeypatch.setattr(main, "UPLOADS", tmp_path)
    with TestClient(main.app) as c:
        yield c


@pytest.fixture
def pdf(tmp_path):
    path = tmp_path / "synthetic.pdf"
    make_sample(path)
    return path.read_bytes()


def test_document_rules_and_coordinates(pdf):
    document = inspect(pdf)
    assert set(f["rule"] for f in document["findings"]) == {"DOC-002", "DOC-003", "DOC-004"}
    with fitz.open(stream=pdf, filetype="pdf") as doc:
        for f in document["findings"]:
            assert all(0 <= v <= 1 for v in f["box"])
            x0, y0, x1, y1 = f["box"]
            assert x1 > x0 and y1 > y0
            page = doc[f["page"] - 1]
            rect = fitz.Rect(x0 * page.rect.width, y0 * page.rect.height, x1 * page.rect.width, y1 * page.rect.height)
            assert page.get_textbox(rect).strip()


def test_rotated_pages():
    doc = fitz.open()
    page = doc.new_page(width=600, height=400)
    page.insert_text((80, 100), "DECK WIDTH: 10", fontsize=15)
    page.set_rotation(90)
    normalized = canonical_pdf(doc.tobytes(), "application/pdf")
    findings = inspect(normalized)["findings"]
    assert any(f["rule"] == "DOC-002" for f in findings)
    with fitz.open(stream=normalized, filetype="pdf") as out:
        assert out[0].rotation == 0
        for f in findings:
            if f["rule"] == "DOC-001":
                continue  # Page-level text absence marker has no text to enclose.
            x0, y0, x1, y1 = f["box"]
            assert (
                out[0]
                .get_textbox(
                    fitz.Rect(
                        x0 * out[0].rect.width, y0 * out[0].rect.height, x1 * out[0].rect.width, y1 * out[0].rect.height
                    )
                )
                .strip()
            )


def test_images_and_unsupported():
    im = Image.new("RGB", (200, 200), "white")
    data = io.BytesIO()
    im.save(data, format="PNG")
    pdf = canonical_pdf(data.getvalue(), "image/png")
    assert inspect(pdf)["support"] == "unsupported-document"
    with pytest.raises(ValueError):
        canonical_pdf(data.getvalue(), "image/jpeg")


def test_validation(client, pdf):
    assert (
        client.post("/api/plans/upload", files={"file": ("x.pdf", b"not a pdf", "application/pdf")}).status_code == 422
    )
    assert client.post("/api/plans/upload", files={"file": ("x.pdf", pdf, "text/plain")}).status_code == 422
    with pytest.raises(ValueError, match="25 MB"):
        canonical_pdf(b"0" * (MAX_BYTES + 1), "application/pdf")
    doc = fitz.open()
    for _ in range(41):
        doc.new_page()
    with pytest.raises(ValueError, match="1–40"):
        canonical_pdf(doc.tobytes(), "application/pdf")


def test_end_to_end_api_exports(client, pdf):
    upload = client.post("/api/plans/upload", files={"file": ("test.pdf", pdf, "application/pdf")})
    assert upload.status_code == 201
    ident = upload.json()["id"]
    assert client.get(f"/api/plans/{ident}/file").content.startswith(b"%PDF")
    result = client.post(f"/api/plans/{ident}/analyze", json={}).json()
    assert result["score"]["state"] == "Insufficient information"
    assert len(result["findings"]) == 3
    f = next(f for f in result["findings"] if f["severity"] == "red")
    r = client.patch("/api/findings/" + f["id"], json={"status": "engineering-review", "note": "=TEST"})
    assert r.status_code == 200
    assert client.get(f"/api/plans/{ident}/findings").status_code == 200
    assert client.get("/api/plans").json()[0]["id"] == ident
    csv = client.get(f"/api/reports/{ident}?format=csv").content.decode("utf-8-sig")
    assert "'=TEST" in csv
    for kind in ["pdf", "annotated"]:
        response = client.get(f"/api/reports/{ident}?format={kind}")
        assert response.status_code == 200
        with fitz.open(stream=response.content, filetype="pdf") as out:
            assert len(out) > 0
            if kind == "annotated":
                assert sum(len(list(p.annots() or [])) for p in out) == 3
    assert client.post(f"/api/plans/{ident}/analyze", json={"values": {"condition": 4}}).status_code == 422
    assert client.post(f"/api/plans/{ident}/analyze", json={"units": "ft"}).status_code == 422
    assert client.patch("/api/findings/" + f["id"], json={"status": "safe"}).status_code == 422
    assert client.get("/api/bridges").json()["total"] == 0
    assert client.get("/api/bridges/unknown").status_code == 404
    assert client.get("/api/reports/unknown").status_code == 404
    assert client.get("/api/overview").json()["total"] == 0
    assert client.get("/api/model/metrics").status_code == 200
    assert client.get("/openapi.json").status_code == 200
