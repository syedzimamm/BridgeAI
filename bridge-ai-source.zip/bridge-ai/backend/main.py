import csv
import io
import json
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, FileResponse
from sqlalchemy import select, func, or_
from backend import db
from backend.schemas import (
    AnalyzeRequest,
    FindingPatch,
    Finding,
    Plan,
    BridgeList,
    Analysis,
    BridgeDetail,
    Overview,
    ModelMetrics,
    Unavailable,
    Report,
)
from backend.documents import canonical_pdf, inspect, MAX_BYTES, annotated_pdf, report_pdf
from backend.inference import score
from ml.features import validate_features

engine = db.connect()
UPLOADS = db.DATA / "uploads"
UPLOADS.mkdir(exist_ok=True)


@asynccontextmanager
async def lifespan(app):
    yield
    engine.dispose()


app = FastAPI(
    title="Bridge AI",
    version="1.0.0",
    lifespan=lifespan,
    description="Local engineering research prototype. Poor condition is not collapse probability.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:3000").split(","),
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Content-Type"],
)


def get_plan(ident):
    with engine.connect() as c:
        row = c.execute(select(db.plans).where(db.plans.c.id == ident)).mappings().first()
        if not row:
            raise HTTPException(404, "Plan not found")
        result = dict(row)
        result["extraction"] = json.loads(result["extraction"])
        result["score"] = json.loads(result["score"]) if result["score"] else None
        values = c.execute(select(db.features.c.values_json).where(db.features.c.plan_id == ident)).scalar()
        result["confirmed_features"] = json.loads(values) if values else None
        return result


def get_findings(ident):
    get_plan(ident)
    with engine.connect() as c:
        result = [
            dict(r)
            for r in c.execute(
                select(db.findings).where(db.findings.c.plan_id == ident).order_by(db.findings.c.page, db.findings.c.id)
            ).mappings()
        ]
    for f in result:
        f["box"] = json.loads(f["box"])
    return result


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/plans/upload", response_model=Plan, status_code=201)
def upload(file: UploadFile = File(...)):
    content = file.file.read(MAX_BYTES + 1)
    try:
        pdf = canonical_pdf(content, file.content_type)
        extraction = inspect(pdf)
    except Exception as e:
        raise HTTPException(422, f"Unsupported or invalid document: {e}") from e
    ident = str(uuid.uuid4())
    found = extraction.pop("findings")
    path = UPLOADS / f"{ident}.pdf"
    path.write_bytes(pdf)
    try:
        with engine.begin() as c:
            c.execute(
                db.plans.insert().values(
                    id=ident,
                    filename=Path((file.filename or "document").replace("\\", "/")).name[:200],
                    created_at=db.now(),
                    pages=len(extraction["pages"]),
                    status="review",
                    extraction=json.dumps(extraction),
                )
            )
            if found:
                c.execute(db.findings.insert(), [dict(f, plan_id=ident, box=json.dumps(f["box"])) for f in found])
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return get_plan(ident)


@app.get("/api/plans", response_model=list[Plan])
def list_plans():
    with engine.connect() as c:
        ids = c.execute(select(db.plans.c.id).order_by(db.plans.c.created_at.desc()).limit(100)).scalars().all()
    return [get_plan(i) for i in ids]


@app.get("/api/plans/{ident}", response_model=Plan)
def plan(ident: str):
    return get_plan(ident)


@app.get("/api/plans/{ident}/file")
def plan_file(ident: str):
    get_plan(ident)
    return FileResponse(
        UPLOADS / f"{ident}.pdf", media_type="application/pdf", headers={"Content-Disposition": "inline"}
    )


@app.post("/api/plans/{ident}/analyze", response_model=Analysis)
def analyze(ident: str, payload: AnalyzeRequest):
    get_plan(ident)
    try:
        values = validate_features(payload.values, payload.units)
    except (ValueError, TypeError) as e:
        raise HTTPException(422, str(e)) from e
    result = score(values, payload.confirmed, payload.context)
    with engine.begin() as c:
        c.execute(db.features.delete().where(db.features.c.plan_id == ident))
        if payload.confirmed:
            c.execute(db.features.insert().values(plan_id=ident, values_json=json.dumps(values), confirmed_at=db.now()))
        c.execute(db.plans.update().where(db.plans.c.id == ident).values(score=json.dumps(result), status="analyzed"))
    return dict(score=result, findings=get_findings(ident))


@app.get("/api/plans/{ident}/findings", response_model=list[Finding])
def findings(ident: str):
    return get_findings(ident)


@app.patch("/api/findings/{ident}", response_model=Finding)
def patch_finding(ident: str, payload: FindingPatch):
    updates = payload.model_dump(exclude_none=True)
    with engine.begin() as c:
        row = c.execute(select(db.findings).where(db.findings.c.id == ident)).mappings().first()
        if not row:
            raise HTTPException(404, "Finding not found")
        if updates:
            c.execute(db.findings.update().where(db.findings.c.id == ident).values(**updates))
        result = dict(row, **updates)
        result["box"] = json.loads(result["box"])
        return result


@app.get("/api/overview", response_model=Overview)
def overview():
    with engine.connect() as c:
        counts = dict(c.execute(select(db.bridges.c.condition, func.count()).group_by(db.bridges.c.condition)).all())
        sources = [dict(r) for r in c.execute(select(db.provenance)).mappings()]
    return dict(total=sum(counts.values()), counts=counts, sources=sources, recent=list_plans()[:5])


@app.get("/api/bridges", response_model=BridgeList)
def bridge_list(
    q: str = Query("", max_length=100),
    state: str | None = Query(None, pattern=r"^\d{2}$"),
    condition: str | None = Query(None, pattern="^(Poor|Fair|Good)$"),
    material: str | None = Query(None, max_length=2),
    year_min: int = 1700,
    year_max: int = 2025,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
):
    filters = [or_(db.bridges.c.year_built.is_(None), db.bridges.c.year_built.between(year_min, year_max))]
    if q:
        filters.append(
            or_(
                db.bridges.c.id.ilike(f"%{q}%"),
                db.bridges.c.location.ilike(f"%{q}%"),
                db.bridges.c.facility.ilike(f"%{q}%"),
            )
        )
    for col, value in [
        (db.bridges.c.state, state),
        (db.bridges.c.condition, condition),
        (db.bridges.c.material, material),
    ]:
        if value:
            filters.append(col == value)
    with engine.connect() as c:
        total = c.execute(select(func.count()).select_from(db.bridges).where(*filters)).scalar()
        items = [
            dict(r)
            for r in c.execute(
                select(db.bridges).where(*filters).order_by(db.bridges.c.id).limit(limit).offset(offset)
            ).mappings()
        ]
    return dict(total=total, items=items)


@app.get("/api/bridges/{ident}", response_model=BridgeDetail)
def bridge_detail(ident: str):
    with engine.connect() as c:
        row = c.execute(select(db.bridges).where(db.bridges.c.id == ident)).mappings().first()
        if not row:
            raise HTTPException(404, "Bridge not found")
        inspection = c.execute(select(db.inspections).where(db.inspections.c.bridge_id == ident)).mappings().all()
        source = c.execute(select(db.provenance).where(db.provenance.c.id == row["source_id"])).mappings().one()
        return dict(bridge=dict(row), inspections=[dict(r) for r in inspection], source=dict(source))


@app.get("/api/model/metrics", response_model=ModelMetrics | Unavailable)
def metrics():
    path = db.DATA / "model" / "metrics.json"
    return json.loads(path.read_text()) if path.exists() else dict(state="Model unavailable")


@app.get("/api/reports/{ident}", response_model=Report)
def report(ident: str, format: str = Query("json", pattern="^(json|csv|pdf|annotated)$")):
    p, f = get_plan(ident), get_findings(ident)
    if format == "json":
        return dict(plan=p, findings=f)
    if format == "csv":
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=list(Finding.model_fields))
        writer.writeheader()
        for row in f:
            # Prevent spreadsheet formula execution in user-edited notes/evidence.
            writer.writerow(
                {
                    k: ("'" + v if isinstance(v, str) and v.lstrip().startswith(("=", "+", "-", "@")) else v)
                    for k, v in row.items()
                }
            )
        data, mime = stream.getvalue().encode("utf-8-sig"), "text/csv"
    else:
        data = annotated_pdf(UPLOADS / f"{ident}.pdf", f) if format == "annotated" else report_pdf(p, f)
        mime = "application/pdf"
    extension = "csv" if format == "csv" else "pdf"
    return Response(
        data,
        media_type=mime,
        headers={"Content-Disposition": f'attachment; filename="bridge-ai-{ident}-{format}.{extension}"'},
    )
