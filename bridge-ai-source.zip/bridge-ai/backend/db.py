"""Portable SQLAlchemy schema. Run numbered additive migrations at startup."""

import os
from pathlib import Path
from datetime import datetime, timezone
from sqlalchemy import (
    create_engine,
    MetaData,
    Table,
    Column,
    String,
    Integer,
    Float,
    Text,
    ForeignKey,
    UniqueConstraint,
    CheckConstraint,
    event,
)

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.getenv("DATA_DIR", str(ROOT / "data")))
DATA.mkdir(parents=True, exist_ok=True)
metadata = MetaData()


def now():
    return datetime.now(timezone.utc).isoformat()


provenance = Table(
    "source_provenance",
    metadata,
    Column("id", String, primary_key=True),
    Column("url", Text, nullable=False),
    Column("sha256", String, nullable=False),
    Column("vintage", Integer, nullable=False),
    Column("imported_at", String, nullable=False),
    Column("details", Text, nullable=False),
)
bridges = Table(
    "bridges",
    metadata,
    Column("id", String, primary_key=True),
    Column("state", String, index=True, nullable=False),
    Column("structure_number", String, nullable=False),
    Column("location", Text),
    Column("facility", Text),
    Column("latitude", Float),
    Column("longitude", Float),
    Column("year_built", Integer, index=True),
    Column("age", Float),
    Column("length_m", Float),
    Column("width_m", Float),
    Column("max_span_m", Float),
    Column("adt", Float),
    Column("spans", Float),
    Column("material", String, index=True),
    Column("design", String),
    Column("condition", String, nullable=False, index=True),
    Column("source_id", String, ForeignKey("source_provenance.id"), nullable=False),
    UniqueConstraint("state", "structure_number"),
    CheckConstraint("condition IN ('Poor','Fair','Good')"),
)
inspections = Table(
    "bridge_inspections",
    metadata,
    Column("id", String, primary_key=True),
    Column("bridge_id", String, ForeignKey("bridges.id"), index=True),
    Column("vintage", Integer, nullable=False),
    Column("inspection_date", String),
    Column("deck", String),
    Column("superstructure", String),
    Column("substructure", String),
    Column("culvert", String),
    UniqueConstraint("bridge_id", "vintage"),
)
samples = Table(
    "training_samples",
    metadata,
    Column("bridge_id", String, ForeignKey("bridges.id"), primary_key=True),
    Column("label", String, nullable=False),
    Column("seed", Integer, nullable=False),
    Column("inclusion_probability", Float, nullable=False),
    Column("source_member", String),
    Column("source_row", Integer),
    CheckConstraint("inclusion_probability > 0 AND inclusion_probability <= 1"),
)
plans = Table(
    "uploaded_plans",
    metadata,
    Column("id", String, primary_key=True),
    Column("filename", String, nullable=False),
    Column("created_at", String, nullable=False),
    Column("pages", Integer, nullable=False),
    Column("status", String, nullable=False),
    Column("extraction", Text, nullable=False),
    Column("score", Text),
)
features = Table(
    "extracted_features",
    metadata,
    Column("plan_id", String, ForeignKey("uploaded_plans.id"), primary_key=True),
    Column("values_json", Text, nullable=False),
    Column("confirmed_at", String, nullable=False),
)
findings = Table(
    "analysis_findings",
    metadata,
    Column("id", String, primary_key=True),
    Column("plan_id", String, ForeignKey("uploaded_plans.id"), index=True),
    Column("page", Integer, nullable=False),
    Column("box", Text, nullable=False),
    Column("severity", String, nullable=False),
    Column("category", String, nullable=False),
    Column("rule", String, nullable=False),
    Column("evidence", Text, nullable=False),
    Column("explanation", Text, nullable=False),
    Column("confidence", Float, nullable=False),
    Column("status", String, nullable=False),
    Column("note", Text, nullable=False),
)
models = Table(
    "model_versions",
    metadata,
    Column("id", String, primary_key=True),
    Column("created_at", String, nullable=False),
    Column("metrics", Text, nullable=False),
    Column("artifact", String, nullable=False),
)
migrations = Table(
    "schema_migrations", metadata, Column("version", Integer, primary_key=True), Column("applied_at", String)
)


def connect(url=None):
    engine = create_engine(url or os.getenv("DATABASE_URL", f"sqlite:///{DATA / 'bridge_ai.db'}"))
    if engine.dialect.name == "sqlite":

        @event.listens_for(engine, "connect")
        def pragmas(connection, _):
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA busy_timeout=30000")

    metadata.create_all(engine)
    with engine.begin() as c:
        if not c.execute(migrations.select().where(migrations.c.version == 1)).first():
            c.execute(migrations.insert().values(version=1, applied_at=now()))
    return engine
