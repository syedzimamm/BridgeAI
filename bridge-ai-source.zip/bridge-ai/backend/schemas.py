from typing import Literal, Any
from pydantic import BaseModel, Field, ConfigDict


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class AnalyzeRequest(Strict):
    values: dict[str, float | str | None] = Field(default_factory=dict)
    units: Literal["m"] = "m"
    confirmed: bool = False
    context: Literal["existing_2025", "proposed", "unknown"] = "unknown"


class FindingPatch(Strict):
    status: Literal["open", "dismissed", "confirmed", "engineering-review"] | None = None
    note: str | None = Field(default=None, max_length=2000)
    explanation: str | None = Field(default=None, min_length=1, max_length=3000)


class Finding(BaseModel):
    id: str
    plan_id: str
    page: int
    box: tuple[float, float, float, float]
    severity: Literal["red", "amber"]
    category: str
    rule: str
    evidence: str
    explanation: str
    confidence: float
    status: str
    note: str


class Plan(BaseModel):
    id: str
    filename: str
    created_at: str
    pages: int
    status: str
    extraction: dict[str, Any]
    score: dict[str, Any] | None = None
    confirmed_features: dict[str, Any] | None = None


class Bridge(BaseModel):
    id: str
    state: str
    structure_number: str
    location: str | None
    facility: str | None
    latitude: float | None
    longitude: float | None
    year_built: int | None
    age: float | None
    length_m: float | None
    width_m: float | None
    max_span_m: float | None
    adt: float | None
    spans: float | None
    material: str | None
    design: str | None
    condition: Literal["Poor", "Fair", "Good"]
    source_id: str


class BridgeList(BaseModel):
    total: int
    items: list[Bridge]


class Analysis(BaseModel):
    score: dict[str, Any]
    findings: list[Finding]


class SourceProvenance(BaseModel):
    id: str
    url: str
    sha256: str
    vintage: int
    imported_at: str
    details: str


class Inspection(BaseModel):
    id: str
    bridge_id: str
    vintage: int
    inspection_date: str | None
    deck: str | None
    superstructure: str | None
    substructure: str | None
    culvert: str | None


class BridgeDetail(BaseModel):
    bridge: Bridge
    inspections: list[Inspection]
    source: SourceProvenance


class Overview(BaseModel):
    total: int
    counts: dict[str, int]
    sources: list[SourceProvenance]
    recent: list[Plan]


class CalibrationBin(BaseModel):
    mean_probability: float
    observed_fraction: float
    count: int


class Evaluation(BaseModel):
    precision: float
    recall: float
    f1: float
    pr_auc: float
    brier: float
    confusion_matrix: list[list[int]]
    calibration: list[CalibrationBin]
    confusion_matrix_note: str


class ModelMetrics(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str
    created_at: str
    winner: str
    test: Evaluation
    validation_comparison: dict[str, Evaluation]
    features: list[str]
    importance: dict[str, float]
    source_provenance: list[SourceProvenance]
    limitations: list[str]


class Unavailable(BaseModel):
    state: str


class Report(BaseModel):
    plan: Plan
    findings: list[Finding]
