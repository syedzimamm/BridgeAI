"""Evidence-bound document checks. No structural capacity or defect inference."""

import re
import io
import uuid
import pymupdf as fitz
import cv2
import numpy as np
from PIL import Image

MAX_BYTES = 25 * 1024 * 1024
MAX_PAGES = 40
LABELS = {"STRUCTURE LENGTH": "length_m", "DECK WIDTH": "width_m", "MAXIMUM SPAN": "max_span_m"}
DIMENSION = re.compile(
    r"\b(STRUCTURE LENGTH|DECK WIDTH|MAXIMUM SPAN)\s*[:=]\s*(\d+(?:\.\d+)?)\s*(mm|cm|m|ft|in)?\b", re.I
)
FACTORS = {"mm": 0.001, "cm": 0.01, "m": 1, "ft": 0.3048, "in": 0.0254}


def canonical_pdf(content, mime):
    if len(content) > MAX_BYTES:
        raise ValueError("File exceeds 25 MB")
    if mime == "application/pdf" and content.startswith(b"%PDF-"):
        doc = fitz.open(stream=content, filetype="pdf")
        if doc.needs_pass or not 1 <= len(doc) <= MAX_PAGES:
            doc.close()
            raise ValueError("PDF must be unencrypted and contain 1–40 pages")
        for page in doc:
            if max(page.rect.width, page.rect.height) > 14400:
                doc.close()
                raise ValueError("Page exceeds supported dimensions")
            # Establish a single coordinate system for PDF.js, extraction and export.
            page.remove_rotation()
            for widget in list(page.widgets() or []):
                page.delete_widget(widget)
        doc.scrub(hidden_text=False, redactions=False, clean_pages=False)
        result = doc.tobytes(garbage=4, deflate=True)
        doc.close()
        return result
    expected = {"image/png": "PNG", "image/jpeg": "JPEG"}
    if mime not in expected:
        raise ValueError("Only PDF, PNG and JPEG are supported")
    with Image.open(io.BytesIO(content)) as im:
        if im.format != expected[mime] or im.width * im.height > 24_000_000:
            raise ValueError("Image type mismatch or image exceeds 24 megapixels")
        im.load()
        clean = io.BytesIO()
        im.convert("RGB").save(clean, format="PNG")
    image_doc = fitz.open(stream=clean.getvalue(), filetype="png")
    pdf = image_doc.convert_to_pdf()
    image_doc.close()
    return pdf


def normalize_box(rect, page):
    r = fitz.Rect(rect)
    return [
        max(0, min(1, r.x0 / page.rect.width)),
        max(0, min(1, r.y0 / page.rect.height)),
        max(0, min(1, r.x1 / page.rect.width)),
        max(0, min(1, r.y1 / page.rect.height)),
    ]


def inspect(pdf):
    found, pages, annotations, candidates = [], [], [], {}
    seen_dimensions = {}
    with fitz.open(stream=pdf, filetype="pdf") as doc:
        text_all = "\n".join(p.get_text() for p in doc)
        for page_index, page in enumerate(doc):
            text = page.get_text()
            pix = page.get_pixmap(
                matrix=fitz.Matrix(
                    min(1, 1000 / max(page.rect.width, page.rect.height)),
                    min(1, 1000 / max(page.rect.width, page.rect.height)),
                ),
                colorspace=fitz.csGRAY,
            )
            gray = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
            quality = float(cv2.Laplacian(gray, cv2.CV_64F).var())
            pages.append(
                dict(
                    number=page_index + 1,
                    width=page.rect.width,
                    height=page.rect.height,
                    text_chars=len(text.strip()),
                    raster_sharpness=quality,
                )
            )

            def add(rule, box, evidence, explanation, severity="amber", confidence=1.0):
                found.append(
                    dict(
                        id=str(uuid.uuid4()),
                        page=page_index + 1,
                        box=box,
                        rule=rule,
                        severity=severity,
                        category="document-based",
                        evidence=evidence,
                        explanation=explanation,
                        confidence=confidence,
                        status="open",
                        note="",
                    )
                )

            if len(text.strip()) < 20:
                add(
                    "DOC-001",
                    [0.03, 0.03, 0.97, 0.13],
                    "Fewer than 20 extractable text characters on this page.",
                    "Text extraction is insufficient. Scanned/image pages need OCR or manual review; this is not evidence of a structural defect.",
                )
            for block in page.get_text("dict")["blocks"]:
                for line in block.get("lines", []):
                    value = "".join(span["text"] for span in line["spans"])
                    box = normalize_box(line["bbox"], page)
                    if re.search(r"\b(scale|concrete|steel|girder|abutment|bearing|pier|load|detail)\b", value, re.I):
                        annotations.append(dict(page=page_index + 1, text=value, box=box))
                    for match in DIMENSION.finditer(value):
                        label, number, unit = match.groups()
                        key = LABELS[label.upper()]
                        if not unit:
                            add(
                                "DOC-002",
                                box,
                                match.group(),
                                "This explicit overall-dimension label has no adjacent unit. A global unit note may apply; confirm it manually.",
                            )
                            continue
                        metres = float(number) * FACTORS[unit.lower()]
                        candidates.setdefault(key, []).append(
                            dict(value=metres, units="m", page=page_index + 1, evidence=match.group(), box=box)
                        )
                        previous = seen_dimensions.get(key)
                        if previous and abs(previous["value"] - metres) > 1e-6:
                            add(
                                "DOC-003",
                                box,
                                f"{previous['evidence']} (page {previous['page']}) versus {match.group()}",
                                "The same overall-dimension label has different stated values. Check scope, revisions and units; this is a document conflict, not a proven engineering defect.",
                                "red",
                            )
                        seen_dimensions[key] = dict(value=metres, evidence=match.group(), page=page_index + 1)
                    for match in re.finditer(r"\bSEE\s+DETAIL\s+([A-Z0-9-]+)", value, re.I):
                        ident = match.group(1)
                        if not re.search(rf"(?m)^\s*DETAIL\s+{re.escape(ident)}\s*(?:$|[:\-])", text_all, re.I):
                            add(
                                "DOC-004",
                                box,
                                match.group(),
                                "A referenced detail heading was not found in extractable text in this upload. It may be on a separate sheet or embedded in an image.",
                            )
    return dict(
        pages=pages,
        candidates=candidates,
        annotations=annotations[:500],
        support="text" if any(p["text_chars"] >= 20 for p in pages) else "unsupported-document",
        rules_version="1.0",
        findings=found,
    )


def annotated_pdf(path, findings):
    with fitz.open(path) as doc:
        for i, f in enumerate(findings, 1):
            if f["status"] == "dismissed":
                continue
            page = doc[f["page"] - 1]
            x0, y0, x1, y1 = f["box"]
            rect = fitz.Rect(x0 * page.rect.width, y0 * page.rect.height, x1 * page.rect.width, y1 * page.rect.height)
            color = (1, 0.12, 0.2) if f["severity"] == "red" else (1, 0.6, 0.1)
            page.draw_rect(rect, color=color, fill=color, fill_opacity=0.15, width=1.5, overlay=True)
            page.insert_text((rect.x0, max(10, rect.y0 - 3)), str(i), color=color, fontsize=9)
            a = page.add_text_annot(
                rect.tl, f"{f['rule']} | {f['status']}\n{f['evidence']}\n{f['explanation']}\nReview note: {f['note']}"
            )
            a.update()
        return doc.tobytes(deflate=True)


def report_pdf(plan, findings):
    doc = fitz.open()
    page = doc.new_page()
    y = 50
    chunks = [
        f"Bridge AI | Findings report\nDocument: {plan['filename']}\nResearch prototype. Not structural safety certification."
    ]
    chunks += [
        f"{i}. Page {f['page']} | {f['rule']} | {f['severity']} | {f['status']}\nEvidence: {f['evidence']}\n{f['explanation']}\nReview note: {f['note']}"
        for i, f in enumerate(findings, 1)
    ]
    if not findings:
        chunks.append("No supported document findings. This does not establish structural safety.")
    for chunk in chunks:
        import textwrap

        lines = "\n".join("\n".join(textwrap.wrap(line, 88)) or " " for line in chunk.split("\n"))
        for line in lines.split("\n"):
            if y > 790:
                page = doc.new_page()
                y = 50
            page.insert_text((45, y), line, fontsize=10)
            y += 14
        y += 18
    result = doc.tobytes()
    doc.close()
    return result
