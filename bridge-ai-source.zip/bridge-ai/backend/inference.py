import joblib
import pandas as pd
from backend.db import DATA
from ml.features import FEATURES, NUMERIC, CATEGORICAL


def score(values, confirmed, context):
    if not confirmed or any(values.get(f) is None for f in FEATURES):
        return dict(
            state="Insufficient information",
            reason="Confirm all eight inventory-compatible inputs, including units, before scoring.",
        )
    if context != "existing_2025":
        return dict(
            state="Unsupported input",
            reason="The model supports existing bridges with inventory-equivalent inputs as of 2025, not proposed designs.",
        )
    artifact = DATA / "model" / "pipeline.joblib"
    if not artifact.exists():
        return dict(state="Model unavailable", reason="Ingest official data and train the local model first.")
    bundle = joblib.load(artifact)  # Only administrator-created local artifacts; never user uploads.
    meta = bundle["metadata"]
    outside = [f for f in NUMERIC if not meta["bounds"][f][0] <= values[f] <= meta["bounds"][f][1]]
    outside += [f for f in CATEGORICAL if values[f] not in meta["categories"][f]]
    if outside:
        return dict(state="Unsupported input", reason="Outside training support: " + ", ".join(outside))
    p = float(bundle["model"].predict_proba(pd.DataFrame([values], columns=FEATURES))[0, 1])
    return dict(
        state="Association estimate",
        probability=p,
        model_id=meta["id"],
        uncertainty="Unvalidated for this document; calibration is measured only on held-out 2025 inventory records.",
        reason="Estimated association with FHWA Poor condition. Not a collapse probability or structural-safety determination.",
    )
