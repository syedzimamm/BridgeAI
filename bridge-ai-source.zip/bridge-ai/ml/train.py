import json
import hashlib
import shutil
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.calibration import CalibratedClassifierCV
from sklearn.frozen import FrozenEstimator
from sklearn.inspection import permutation_importance
from sqlalchemy import select
from backend.db import connect, bridges, samples, provenance, models, DATA, now
from ml.features import FEATURES, NUMERIC, CATEGORICAL
from ml.evaluate import evaluate


def train():
    engine = connect()
    with engine.connect() as c:
        frame = pd.read_sql(select(bridges, samples.c.inclusion_probability).join(samples), c)
        sources = [dict(r) for r in c.execute(select(provenance)).mappings()]
    if len(frame) < 20000 or frame.id.duplicated().any():
        raise ValueError("Run verified ingestion first; need 20,000 unique real bridges")
    x = frame[FEATURES].copy()
    x.columns = [str(column) for column in x.columns]
    y = (frame.condition == "Poor").astype(int)
    weight = 1 / frame.inclusion_probability
    # Four disjoint sets: fitting, candidate selection, calibration, final evaluation.
    fit, rest = train_test_split(np.arange(len(frame)), test_size=0.4, random_state=42, stratify=y)
    val, rest = train_test_split(rest, test_size=0.75, random_state=43, stratify=y.iloc[rest])
    cal, test = train_test_split(rest, test_size=2 / 3, random_state=44, stratify=y.iloc[rest])
    preprocess = ColumnTransformer(
        [
            ("numeric", SimpleImputer(strategy="median", add_indicator=True), NUMERIC),
            (
                "category",
                Pipeline(
                    [
                        ("fill", SimpleImputer(strategy="most_frequent")),
                        ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
                    ]
                ),
                CATEGORICAL,
            ),
        ]
    )
    candidates = {
        "random_forest": RandomForestClassifier(
            n_estimators=160, min_samples_leaf=5, max_features=0.8, n_jobs=-1, random_state=42
        ),
        "gradient_boosting": HistGradientBoostingClassifier(
            max_iter=160, max_leaf_nodes=15, l2_regularization=2, random_state=42
        ),
    }
    comparison, fitted = {}, {}
    for name, estimator in candidates.items():
        pipeline = Pipeline([("preprocess", preprocess), ("classifier", estimator)])
        # Outcome-stratified sampling supplies minority examples; IPW restores source prevalence.
        pipeline.fit(x.iloc[fit], y.iloc[fit], classifier__sample_weight=weight.iloc[fit].to_numpy())
        comparison[name] = evaluate(y.iloc[val], pipeline.predict_proba(x.iloc[val])[:, 1], weight.iloc[val])
        fitted[name] = pipeline
        # A new transformer per candidate prevents shared fitted state.
        from sklearn.base import clone

        preprocess = clone(preprocess)
    winner = max(comparison, key=lambda k: comparison[k]["pr_auc"])
    model = CalibratedClassifierCV(FrozenEstimator(fitted[winner]), method="sigmoid")
    model.fit(x.iloc[cal], y.iloc[cal], sample_weight=weight.iloc[cal].to_numpy())
    probability = model.predict_proba(x.iloc[test])[:, 1]
    evaluation = evaluate(y.iloc[test], probability, weight.iloc[test])
    importance = permutation_importance(
        model,
        x.iloc[test],
        y.iloc[test],
        n_repeats=3,
        scoring="average_precision",
        sample_weight=weight.iloc[test].to_numpy(),
        random_state=42,
    )
    bounds = {f: [float(x.iloc[fit][f].min()), float(x.iloc[fit][f].max())] for f in NUMERIC}
    categories = {f: sorted(x.iloc[fit][f].dropna().unique().tolist()) for f in CATEGORICAL}
    identifier = now().replace(":", "-").replace(".", "-")
    report = dict(
        id=identifier,
        created_at=now(),
        winner=winner,
        validation_comparison=comparison,
        test=evaluation,
        features=FEATURES,
        bounds=bounds,
        categories=categories,
        importance=dict(zip(FEATURES, importance.importances_mean.tolist())),
        splits={k: len(v) for k, v in dict(train=fit, validation=val, calibration=cal, test=test).items()},
        source_provenance=sources,
        population_prevalence=float(np.average(y, weights=weight)),
        split_method="2025 cross-sectional stratified split by unique state + structure ID; no longitudinal evidence",
        weighting="Inverse sample inclusion probabilities in fitting, calibration and metrics; counts unweighted",
        limitations=[
            "Research association only; no collapse probability or engineering certification.",
            "Single inventory year. Age and traffic are as observed in 2025; not validated for proposed bridges.",
            "Unmeasured inspection practices, exposure and maintenance confound associations.",
            "No external, temporal or project-specific validation. Calibration may drift.",
        ],
    )
    folder = DATA / "model"
    folder.mkdir(exist_ok=True)
    artifact = folder / "pipeline.joblib"
    joblib.dump(dict(model=model, metadata=report), artifact)
    versions = folder / "versions"
    versions.mkdir(exist_ok=True)
    version_artifact = versions / f"{identifier}.joblib"
    shutil.copyfile(artifact, version_artifact)
    report["artifact_sha256"] = hashlib.sha256(artifact.read_bytes()).hexdigest()
    (folder / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (folder / "feature_schema.json").write_text(
        json.dumps(dict(features=FEATURES, units="m", bounds=bounds, categories=categories), indent=2)
    )
    (folder / "splits.json").write_text(
        json.dumps(
            {
                k: frame.id.iloc[v].tolist()
                for k, v in dict(train=fit, validation=val, calibration=cal, test=test).items()
            }
        )
    )
    np.savez(folder / "test_predictions.npz", y=y.iloc[test], probability=probability, weights=weight.iloc[test])
    with engine.begin() as c:
        c.execute(
            models.insert().values(
                id=identifier, created_at=now(), metrics=json.dumps(report), artifact=str(version_artifact)
            )
        )
    print(json.dumps(dict(winner=winner, test=evaluation, splits=report["splits"]), indent=2))
    return report


if __name__ == "__main__":
    train()
