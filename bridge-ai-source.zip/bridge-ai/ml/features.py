"""Single allowlist shared by training and inference. Condition fields never enter X."""

import math

NUMERIC = ["age", "length_m", "width_m", "max_span_m", "adt", "spans"]
CATEGORICAL = ["material", "design"]
FEATURES = NUMERIC + CATEGORICAL


def validate_features(values, units):
    if set(values) - set(FEATURES):
        raise ValueError("Unknown features; inspection ratings and labels are prohibited")
    if units != "m":
        raise ValueError("Confirm dimensions converted to metres before scoring")
    out = {}
    for key in FEATURES:
        value = values.get(key)
        if value is None or value == "":
            out[key] = None
        elif key in NUMERIC:
            v = float(value)
            if not math.isfinite(v) or v < 0 or (key in ("length_m", "width_m", "max_span_m", "spans") and v == 0):
                raise ValueError(f"Invalid {key}")
            out[key] = v
        else:
            out[key] = str(value).zfill(2) if key == "design" else str(value)
    return out
