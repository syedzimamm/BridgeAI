import json
import argparse
import numpy as np
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    average_precision_score,
    confusion_matrix,
    brier_score_loss,
)


def evaluate(y, probability, weights=None):
    p = np.asarray(probability)
    y = np.asarray(y)
    w = np.ones(len(y)) if weights is None else np.asarray(weights)
    predicted = p >= 0.5
    calibration = []
    for lo in np.arange(0, 1, 0.1):
        mask = (p >= lo) & (p < lo + 0.1 + (1e-9 if lo > 0.89 else 0))
        if mask.any():
            calibration.append(
                dict(
                    mean_probability=float(np.average(p[mask], weights=w[mask])),
                    observed_fraction=float(np.average(y[mask], weights=w[mask])),
                    count=int(mask.sum()),
                )
            )
    return dict(
        precision=float(precision_score(y, predicted, sample_weight=w, zero_division=0)),
        recall=float(recall_score(y, predicted, sample_weight=w, zero_division=0)),
        f1=float(f1_score(y, predicted, sample_weight=w, zero_division=0)),
        pr_auc=float(average_precision_score(y, p, sample_weight=w)),
        brier=float(brier_score_loss(y, p, sample_weight=w)),
        confusion_matrix=confusion_matrix(y, predicted).tolist(),
        calibration=calibration,
        confusion_matrix_note="Unweighted held-out sample counts: rows actual [not Poor, Poor]; columns predicted",
    )


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--predictions", default="data/model/test_predictions.npz")
    a = p.parse_args()
    with np.load(a.predictions) as data:
        print(json.dumps(evaluate(data["y"], data["probability"], data["weights"]), indent=2))
