# Generated local data

The database, model and uploads are local generated artifacts, excluded from Git.
Regenerate them with the ingestion and training commands in the root README.
No full government archive or user-uploaded drawings are committed.
