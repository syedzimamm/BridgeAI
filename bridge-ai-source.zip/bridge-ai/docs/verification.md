# Local verification

Verified on Windows, October 8, 2026, using Python 3.12 and the locked frontend dependencies.

- Official 2025 archive downloaded and actual headers/rows parsed; 624,193 source rows checked.
- SQLite contains 20,000 unique bridges, 20,000 inspection rows and 20,000 provenance-linked training samples: 10,000 Poor, 5,000 Fair, 5,000 Good.
- Random Forest and histogram gradient boosting fitted on real records. Random Forest selected using validation PR-AUC. Full held-out evaluation is in `evaluation.json`.
- 27 Python tests passed, including real database counts/provenance, model inference, duplicate-free split membership, source-format parsing, leakage prevention, units, upload validation, rotated PDF coordinates, state editing and exported PDF/CSV reports.
- Python lint passed.
- Frontend type checking, overlay unit test and production build passed.
- Two Chrome end-to-end tests passed: upload, evidence overlays, zoom/resize pixel alignment, persisted review status, no-information state, annotated export and five-page navigation.
- Dashboard and annotation screenshots inspected visually; stored in this directory.

Container launch was not exercised because Docker is not installed in the execution environment. PostgreSQL was not available; compatibility is implemented at the SQLAlchemy schema/driver level but is not integration-tested. GitHub Actions is provided but has not run remotely. No authorized GitHub destination was supplied and GitHub CLI was unavailable, so nothing was pushed.

No structural-engineering validation was performed. At threshold 0.5, recall is only 0.1045. This software must not be used to clear a bridge of possible defects or determine safety. Image-only plans receive an unsupported-text state; OCR and engineering calculation modules are not implemented.
