# Review rules v1.0

These are document-integrity checks. They do not assess structural capacity or compliance.

| Rule | Trigger | Overlay | Evidence / limitations |
|---|---|---|---|
| DOC-001 | Fewer than 20 extractable text characters on a page | Amber page-header band | A text-extraction coverage check; a short page or scan may be intentional. No OCR is performed. The band marks the page, not a physical component. |
| DOC-002 | `STRUCTURE LENGTH`, `DECK WIDTH` or `MAXIMUM SPAN`, followed by `:` or `=`, a number and no supported adjacent unit | Amber text-line box | Global unit notes may apply; asks for human confirmation. |
| DOC-003 | The same one of those explicit overall labels has different normalized numeric values in the upload | Red text-line box at the later occurrence | Includes earlier page and both values. Different scopes or revisions may explain the conflict. No defect is asserted. `1e-6 m` tolerance only removes floating-point conversion noise; it is not an engineering limit. |
| DOC-004 | `SEE DETAIL X` without an extractable line heading `DETAIL X` | Amber reference-line box | A referenced sheet may be separate or its heading may be an image. This is not proof the detail does not exist. |

Unit vocabulary is mm, cm, m, ft and in. Unsupported units or other notation remain unconfirmed. Auto-extraction is intentionally narrow and never fills age/traffic/material codes from ambiguous text. All feature meanings must match FHWA inventory definitions; overall bridge length is not a beam length. The browser requires explicit user confirmation and compatible inventory-year context before scoring.

Confidence 1.0 indicates a deterministic text-rule match, not certainty of an engineering defect. Rules are document-based. There are currently no authenticated engineering rules and no geometry-based model overlays. A model estimate is shown separately and cannot legitimately be assigned to a drawing component.

Boxes are `[x0, y0, x1, y1]` normalized to each canonical PDF page. The origin is top-left. The browser uses percentages inside the PDF canvas container. Export multiplies by that same page width/height. Rotated input pages are normalized first. Findings are selected by stable UUID; displayed numbers use the same ordering in the viewer and export. Dismissed findings remain in reports but their overlay is omitted from the annotated PDF.

Editing a finding changes the review explanation/note/status; original evidence and rule remain immutable. Clicking a finding switches page, increases zoom if necessary, and scrolls to its marker. No model association is used to manufacture geometric evidence.
