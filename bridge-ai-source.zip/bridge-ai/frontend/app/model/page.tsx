"use client";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";
import { useData, Metrics } from "@/lib/api";
import { PageTitle, ErrorBox, Empty } from "@/components/Common";
export default function Model() {
  const { data, error } = useData<Metrics>("/model/metrics");
  return (
    <>
      <PageTitle
        eyebrow="TRANSPARENT BY DESIGN"
        title="The model, explained"
        description="Condition association, measured on held-out inventory records. No safety certification."
      />
      <ErrorBox error={error} />
      {!data?.test ? (
        <Empty>{data?.state || "Loading model metadata…"}</Empty>
      ) : (
        <>
          <section className="stats">
            {(["precision", "recall", "f1", "pr_auc", "brier"] as const).map(
              (k) => (
                <div className="stat" key={k}>
                  <span>{k.replace("_", " ").toUpperCase()}</span>
                  <strong>{data.test[k].toFixed(3)}</strong>
                  <small>Held-out · prevalence weighted</small>
                </div>
              ),
            )}
          </section>
          <div className="grid-two">
            <section className="panel">
              <h3>Global feature importance</h3>
              <p>
                Permutation drop in weighted test PR-AUC; not causal or a local
                explanation.
              </p>
              <ResponsiveContainer width="100%" height={270}>
                <BarChart
                  data={Object.entries(data.importance)
                    .map(([name, value]) => ({ name, value }))
                    .sort((a, b) => b.value - a.value)}
                  layout="vertical"
                  margin={{ left: 25, right: 20 }}
                >
                  <XAxis type="number" stroke="#8892aa" />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={100}
                    stroke="#aeb8cf"
                    fontSize={11}
                  />
                  <Tooltip />
                  <Bar
                    dataKey="value"
                    fill="#a58ae9"
                    isAnimationActive={false}
                  />
                </BarChart>
              </ResponsiveContainer>
            </section>
            <section className="panel">
              <h3>Calibration</h3>
              <p>
                Mean estimated association versus observed Poor-condition
                fraction.
              </p>
              <ResponsiveContainer width="100%" height={270}>
                <LineChart
                  data={data.test.calibration}
                  margin={{ left: 0, right: 25, bottom: 15 }}
                >
                  <CartesianGrid stroke="#282c3b" />
                  <XAxis
                    type="number"
                    dataKey="mean_probability"
                    domain={[0, 1]}
                    stroke="#8892aa"
                  />
                  <YAxis domain={[0, 1]} stroke="#8892aa" />
                  <Tooltip />
                  <Line
                    dataKey="observed_fraction"
                    stroke="#9b80ef"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </section>
          </div>
          <section className="panel">
            <h3>Training & evaluation</h3>
            <p>
              Selected model:{" "}
              <strong>{data.winner.replaceAll("_", " ")}</strong> · Source Poor
              prevalence: {(100 * data.population_prevalence).toFixed(2)}%
            </p>
            <p>{data.split_method}</p>
            <p>{data.weighting}</p>
            <div className="chips">
              {Object.entries(data.splits).map(([k, v]) => (
                <span className="badge" key={k}>
                  {k}: {v.toLocaleString()}
                </span>
              ))}
            </div>
            <table>
              <thead>
                <tr>
                  <th>Candidate</th>
                  <th>Validation PR-AUC</th>
                  <th>Validation F1</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(data.validation_comparison).map(([k, v]) => (
                  <tr key={k}>
                    <td>{k}</td>
                    <td>{v.pr_auc.toFixed(3)}</td>
                    <td>{v.f1.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <h3>Confusion matrix · unweighted test counts</h3>
            <table>
              <thead>
                <tr>
                  <th>Actual / predicted</th>
                  <th>Not Poor</th>
                  <th>Poor</th>
                </tr>
              </thead>
              <tbody>
                {data.test.confusion_matrix.map((r, i) => (
                  <tr key={i}>
                    <td>{i ? "Poor" : "Not Poor"}</td>
                    {r.map((n, j) => (
                      <td key={j}>{n}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <section className="panel">
            <h3>Known limitations</h3>
            <ul>
              {data.limitations.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
            <h3>Dataset provenance</h3>
            {data.source_provenance.map((s) => (
              <div key={s.sha256}>
                <a href={s.url}>FHWA {s.vintage} official archive ↗</a>
                <p className="hash">SHA-256: {s.sha256}</p>
              </div>
            ))}
          </section>
        </>
      )}
    </>
  );
}
