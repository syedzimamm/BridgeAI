"use client";
import Link from "next/link";
import {
  ArrowUpRight,
  Database,
  ShieldCheck,
  ScanLine,
  ArrowRight,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";
import { useData, Overview, Metrics } from "@/lib/api";
import { PageTitle, ErrorBox, Empty } from "@/components/Common";
export default function Home() {
  const { data, error } = useData<Overview>("/overview");
  const model = useData<Metrics>("/model/metrics");
  const chart = ["Poor", "Fair", "Good"].map((name) => ({
    name,
    count: data?.counts[name] || 0,
  }));
  return (
    <>
      <PageTitle
        eyebrow="YOUR WORKSPACE, AT A GLANCE"
        title="Bridge intelligence. Grounded in evidence."
        description="Explore real bridge records and bring clarity to your plan review."
        action={
          <Link className="button" href="/analyze">
            Analyze a plan <ArrowUpRight size={17} />
          </Link>
        }
      />
      <ErrorBox error={error} />
      <section className="hero">
        <div>
          <span className="badge purple">
            DOCUMENT REVIEW + INVENTORY RESEARCH
          </span>
          <h2>
            Every detail deserves
            <br />a closer look.
          </h2>
          <p>
            Turn bridge plans into a traceable review.
            <br />
            Find the evidence, inspect the context, make an informed decision.
          </p>
          <Link href="/analyze" className="hero-link">
            Start document review <ArrowRight size={18} />
          </Link>
        </div>
        <div className="bridge-art" aria-hidden="true">
          <svg viewBox="0 0 520 240">
            <defs>
              <linearGradient id="beam">
                <stop stopColor="#7761d7" />
                <stop offset="1" stopColor="#c5b8ff" />
              </linearGradient>
            </defs>
            <path
              d="M20 174L485 90M20 185L485 101M80 164L80 222M229 137L229 195M400 106L400 164"
              stroke="url(#beam)"
              strokeWidth="6"
            />
            <path
              d="M55 168L140 73L220 139L300 45L389 109L469 15M140 73L140 153M300 45L300 124M469 15L469 94M55 168L220 139L389 109L469 94"
              fill="none"
              stroke="#a991ff"
              strokeWidth="3"
            />
            <path d="M30 209L489 126M95 231L512 155" stroke="#342951" />
            <circle cx="300" cy="45" r="8" fill="#c3acff" />
            <circle cx="220" cy="139" r="8" fill="#c3acff" />
          </svg>
          <div className="art-caption">
            <span /> EVIDENCE-LED ANALYSIS
          </div>
        </div>
      </section>
      <section className="stats">
        <div className="stat">
          <Database />
          <span>Real bridge records</span>
          <strong>{data ? data.total.toLocaleString() : "—"}</strong>
          <small>Reproducible FHWA sample</small>
        </div>
        <div className="stat">
          <ScanLine />
          <span>Poor-condition records</span>
          <strong>
            {data ? (data.counts.Poor || 0).toLocaleString() : "—"}
          </strong>
          <small>Condition ratings, not failures</small>
        </div>
        <div className="stat">
          <ShieldCheck />
          <span>Held-out PR-AUC</span>
          <strong>
            {model.data?.test ? model.data.test.pr_auc.toFixed(3) : "—"}
          </strong>
          <small>Weighted to source prevalence</small>
        </div>
      </section>
      <div className="grid-two">
        <section className="panel">
          <div className="panel-title">
            <h3>Inventory composition</h3>
            <span className="badge">2025 SAMPLE</span>
          </div>
          <p>Condition-stratified sample · not national proportions</p>
          {data?.total ? (
            <div className="chart">
              <ResponsiveContainer width="100%" height={210}>
                <BarChart
                  data={chart}
                  layout="vertical"
                  margin={{ left: 10, right: 30 }}
                >
                  <XAxis type="number" stroke="#758096" fontSize={11} />
                  <YAxis
                    dataKey="name"
                    type="category"
                    stroke="#b6bdd0"
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "#141827",
                      border: "1px solid #30354b",
                      borderRadius: 8,
                    }}
                  />
                  <Bar
                    dataKey="count"
                    radius={[0, 5, 5, 0]}
                    barSize={25}
                    isAnimationActive={false}
                  >
                    {["#ef6678", "#dfb968", "#6fc6a7"].map((c) => (
                      <Cell key={c} fill={c} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <Empty>
              Database not populated. Run the FHWA ingestion command in the
              README.
            </Empty>
          )}
        </section>
        <section className="panel">
          <div className="panel-title">
            <h3>Recent document reviews</h3>
            <Link href="/reports">View all ↗</Link>
          </div>
          {data?.recent.length ? (
            data.recent.map((p) => (
              <Link
                className="document-row"
                href={`/analyze?id=${p.id}`}
                key={p.id}
              >
                <span className="file-icon">
                  <ScanLine size={20} />
                </span>
                <div>
                  <strong>{p.filename}</strong>
                  <small>
                    {p.pages} pages ·{" "}
                    {new Date(p.created_at).toLocaleDateString()}
                  </small>
                </div>
                <span className="badge">{p.status}</span>
              </Link>
            ))
          ) : (
            <Empty>
              No documents yet. Upload a plan to begin an evidence-backed
              review.
            </Empty>
          )}
        </section>
      </div>
      <div className="notice">
        <ShieldCheck size={20} />
        <div>
          <strong>A review aid, with clear boundaries.</strong>
          <p>
            Document conflicts and missing information are distinct from
            structural hazards. No automated result certifies a bridge as safe.
          </p>
        </div>
      </div>
    </>
  );
}
