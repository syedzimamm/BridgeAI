"use client";
import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";
import { UploadCloud, Check, FileSearch } from "lucide-react";
import { api, Finding, Plan, Score } from "@/lib/api";
import { Downloads, ErrorBox, PageTitle, Empty } from "@/components/Common";
const Viewer = dynamic(() => import("@/components/Viewer"), { ssr: false });
const fields: Record<string, string> = {
  age: "Age in 2025 (years)",
  length_m: "Structure length (m)",
  width_m: "Deck width (m)",
  max_span_m: "Maximum span (m)",
  adt: "Average daily traffic",
  spans: "Main spans",
  material: "NBI material code (43A)",
  design: "NBI design code (43B)",
};
export default function Analyze() {
  const [plan, setPlan] = useState<Plan>(),
    [findings, setFindings] = useState<Finding[]>([]),
    [selected, setSelected] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [drag, setDrag] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({}),
    [confirmed, setConfirmed] = useState(false),
    [context, setContext] = useState("unknown"),
    [score, setScore] = useState<Score>();
  const input = useRef<HTMLInputElement>(null);
  async function load(p: Plan) {
    setPlan(p);
    setScore(p.score || undefined);
    setConfirmed(false);
    setContext("unknown");
    setSelected("");
    const initial: Record<string, string> = {};
    for (const [k, v] of Object.entries(p.extraction.candidates)) {
      if (v.length === 1) initial[k] = String(v[0].value);
    }
    for (const [k, v] of Object.entries(p.confirmed_features || {})) {
      if (v !== null) initial[k] = String(v);
    }
    setValues(initial);
    setFindings(await api<Finding[]>(`/plans/${p.id}/findings`));
  }
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("id");
    if (id)
      api<Plan>(`/plans/${id}`)
        .then(load)
        .catch((e) => setError(e.message));
  }, []);
  async function upload(file?: File) {
    if (!file) return;
    setError("");
    if (file.size > 25 * 1024 * 1024) {
      setError("Maximum upload size is 25 MB.");
      return;
    }
    setBusy(true);
    try {
      const form = new FormData();
      form.append("file", file);
      await load(
        await api<Plan>("/plans/upload", { method: "POST", body: form }),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function analyze() {
    if (!plan) return;
    setBusy(true);
    setError("");
    try {
      const result = await api<{ score: Score; findings: Finding[] }>(
        `/plans/${plan.id}/analyze`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ values, units: "m", confirmed, context }),
        },
      );
      setScore(result.score);
      setFindings(result.findings);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function update(id: string, patch: Record<string, string>) {
    try {
      const next = await api<Finding>(`/findings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      setFindings((fs) => fs.map((f) => (f.id === id ? next : f)));
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="EVIDENCE-LED DOCUMENT REVIEW"
        title="Analyze plans"
        description="Inspect annotations, resolve missing information and confirm the context."
      />
      <ErrorBox error={error} />
      <input
        ref={input}
        type="file"
        accept="application/pdf,image/png,image/jpeg"
        hidden
        onChange={(e) => upload(e.target.files?.[0])}
      />
      <div
        role="button"
        tabIndex={0}
        aria-label="Upload a bridge plan"
        className={`upload ${drag ? "drag" : ""} ${plan ? "compact" : ""}`}
        onClick={() => !busy && input.current?.click()}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            input.current?.click();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (!busy) upload(e.dataTransfer.files[0]);
        }}
      >
        <UploadCloud size={plan ? 24 : 36} />
        <div>
          <strong>
            {busy
              ? "Processing…"
              : plan
                ? plan.filename
                : "Drop a bridge plan here, or browse files"}
          </strong>
          <p>PDF, PNG or JPG · up to 25 MB · 40 pages</p>
        </div>
        {plan && <span className="badge">REPLACE DOCUMENT</span>}
      </div>
      {plan && (
        <>
          <div className="review-title">
            <div>
              <h3>Document workspace</h3>
              <span>
                {plan.pages} pages · {findings.length} supported findings
              </span>
            </div>
            <Downloads id={plan.id} />
          </div>
          <div className="review-grid">
            <Viewer
              id={plan.id}
              pages={plan.pages}
              findings={findings}
              selected={selected}
              onSelect={setSelected}
            />
            <section className="findings">
              <h3>
                <FileSearch size={18} /> Review findings
              </h3>
              <p className="muted">
                Confidence describes the text rule match, not structural risk.
              </p>
              {findings.length ? (
                findings.map((f, i) => (
                  <article
                    key={f.id}
                    className={`finding ${f.severity} ${selected === f.id ? "chosen" : ""}`}
                  >
                    <button
                      className="finding-focus"
                      onClick={() => setSelected(f.id)}
                    >
                      <span className={`number ${f.severity}`}>{i + 1}</span>
                      <strong>
                        {f.rule === "DOC-003"
                          ? "Conflicting dimensions"
                          : f.rule === "DOC-002"
                            ? "Units need confirmation"
                            : f.rule === "DOC-004"
                              ? "Referenced detail not found"
                              : "Limited text extraction"}
                      </strong>
                      <small>p. {f.page}</small>
                    </button>
                    <blockquote>{f.evidence}</blockquote>
                    <p>{f.explanation}</p>
                    <div className="finding-meta">
                      {f.category} · {(f.confidence * 100).toFixed(0)}% rule
                      confidence
                    </div>
                    <label>
                      Review status
                      <select
                        aria-label={`Review status for finding ${i + 1}`}
                        value={f.status}
                        onChange={(e) =>
                          update(f.id, { status: e.target.value })
                        }
                      >
                        {[
                          "open",
                          "confirmed",
                          "dismissed",
                          "engineering-review",
                        ].map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </label>
                    <details>
                      <summary>Edit explanation / add review note</summary>
                      <label>
                        Explanation
                        <textarea
                          defaultValue={f.explanation}
                          onBlur={(e) => {
                            if (e.target.value !== f.explanation)
                              update(f.id, { explanation: e.target.value });
                          }}
                        />
                      </label>
                      <label>
                        Review note
                        <textarea
                          defaultValue={f.note}
                          placeholder="Add context for the reviewer"
                          onBlur={(e) => {
                            if (e.target.value !== f.note)
                              update(f.id, { note: e.target.value });
                          }}
                        />
                      </label>
                    </details>
                  </article>
                ))
              ) : (
                <Empty>
                  No supported document issues found. This does not establish
                  structural safety.
                </Empty>
              )}
            </section>
          </div>
          <section className="panel feature-panel">
            <div className="panel-title">
              <h3>Confirm inventory-compatible features</h3>
              <span className="badge purple">HUMAN REVIEW REQUIRED</span>
            </div>
            <p>
              Dimensions are only suggested from explicit overall labels.
              Confirm their scope and convert to metres. Age and traffic require
              existing-bridge records; design drawings alone are usually
              insufficient.
            </p>
            <div className="feature-grid">
              {Object.entries(fields).map(([key, label]) => (
                <label key={key}>
                  {label}
                  <input
                    value={values[key] || ""}
                    type={
                      ["material", "design"].includes(key) ? "text" : "number"
                    }
                    min="0"
                    step="any"
                    placeholder="Not provided"
                    onChange={(e) => {
                      setValues({ ...values, [key]: e.target.value });
                      setConfirmed(false);
                    }}
                  />
                  {plan.extraction.candidates[key]?.map((v, i) => (
                    <small key={i}>
                      p. {v.page}: {v.evidence}
                    </small>
                  ))}
                </label>
              ))}
            </div>
            <label className="context-select">
              Document context
              <select
                value={context}
                onChange={(e) => {
                  setContext(e.target.value);
                  setConfirmed(false);
                }}
              >
                <option value="unknown">Unknown / insufficient evidence</option>
                <option value="existing_2025">
                  Existing bridge · inputs verified as of 2025
                </option>
                <option value="proposed">Proposed bridge design</option>
              </select>
            </label>
            <label className="checkbox">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
              />{" "}
              I confirmed the feature meanings, NBI codes, units and
              inventory-year context.
            </label>
            <button className="button" disabled={busy} onClick={analyze}>
              <Check size={17} /> Compare with inventory model
            </button>
            {score && (
              <div className="score" role="status">
                <h3>
                  {score.state}
                  {score.probability !== undefined
                    ? ` · ${(score.probability * 100).toFixed(1)}%`
                    : ""}
                </h3>
                <p>{score.reason}</p>
                {score.uncertainty && <small>{score.uncertainty}</small>}
              </div>
            )}
            <details>
              <summary>
                Extracted materials, component names, scales and notes
              </summary>
              {plan.extraction.annotations.length ? (
                plan.extraction.annotations.map((a, i) => (
                  <p key={i}>
                    <span className="badge">p. {a.page}</span> {a.text}
                  </p>
                ))
              ) : (
                <p>No readable component annotations found.</p>
              )}
            </details>
          </section>
        </>
      )}
    </>
  );
}
