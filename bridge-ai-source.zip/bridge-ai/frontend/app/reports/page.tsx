"use client";
import Link from "next/link";
import { useData, Plan } from "@/lib/api";
import { PageTitle, ErrorBox, Empty, Downloads } from "@/components/Common";
export default function Reports() {
  const { data, error } = useData<Plan[]>("/plans");
  return (
    <>
      <PageTitle
        eyebrow="A TRACEABLE REVIEW HISTORY"
        title="Reports"
        description="Reopen a document review or export its latest annotations and findings."
      />
      <ErrorBox error={error} />
      {data?.length ? (
        data.map((p) => (
          <section className="panel report-row" key={p.id}>
            <div>
              <Link href={`/analyze?id=${p.id}`}>
                <h3>{p.filename} ↗</h3>
              </Link>
              <p>
                {new Date(p.created_at).toLocaleString()} · {p.pages} pages ·{" "}
                {p.status}
              </p>
              <span className="badge">{p.score?.state || "Not scored"}</span>
            </div>
            <Downloads id={p.id} />
          </section>
        ))
      ) : (
        <Empty>
          No reviews saved yet.{" "}
          <Link href="/analyze">Analyze your first plan ↗</Link>
        </Empty>
      )}
    </>
  );
}
