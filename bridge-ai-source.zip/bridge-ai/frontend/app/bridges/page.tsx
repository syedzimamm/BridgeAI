"use client";
import dynamic from "next/dynamic";
import { useState } from "react";
import { api, Bridge, useData } from "@/lib/api";
import { PageTitle, ErrorBox } from "@/components/Common";
const Map = dynamic(() => import("@/components/BridgeMap"), { ssr: false });
type Detail = {
  bridge: Bridge;
  inspections: {
    inspection_date: string;
    deck: string;
    superstructure: string;
    substructure: string;
    culvert: string;
  }[];
  source: { url: string; vintage: number; sha256: string };
};
export default function Bridges() {
  const [q, setQ] = useState(""),
    [state, setState] = useState(""),
    [condition, setCondition] = useState("Poor"),
    [material, setMaterial] = useState(""),
    [year, setYear] = useState("1700"),
    [offset, setOffset] = useState(0),
    [detail, setDetail] = useState<Detail>(),
    [detailError, setDetailError] = useState("");
  const params = new URLSearchParams({
    q,
    year_min: year || "1700",
    offset: String(offset),
    limit: "50",
  });
  if (state) params.set("state", state);
  if (condition) params.set("condition", condition);
  if (material) params.set("material", material);
  const { data, error } = useData<{ items: Bridge[]; total: number }>(
    `/bridges?${params}`,
  );
  return (
    <>
      <PageTitle
        eyebrow="OFFICIAL FHWA INVENTORY"
        title="Bridge database"
        description="Real bridge records. Traceable condition ratings. A reproducible research sample."
      />
      <ErrorBox error={error || detailError} />
      <div className="filters">
        <label>
          Search
          <input
            placeholder="Bridge ID, facility or location"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setOffset(0);
            }}
          />
        </label>
        <label>
          State FIPS
          <input
            placeholder="e.g. 06"
            maxLength={2}
            value={state}
            onChange={(e) => {
              setState(e.target.value);
              setOffset(0);
            }}
          />
        </label>
        <label>
          Condition
          <select
            value={condition}
            onChange={(e) => {
              setCondition(e.target.value);
              setOffset(0);
            }}
          >
            <option value="">All conditions</option>
            {["Poor", "Fair", "Good"].map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label>
          Material code
          <input
            placeholder="e.g. 3"
            value={material}
            onChange={(e) => {
              setMaterial(e.target.value);
              setOffset(0);
            }}
          />
        </label>
        <label>
          Built since
          <input
            type="number"
            min="1700"
            max="2025"
            value={year}
            onChange={(e) => {
              setYear(e.target.value);
              setOffset(0);
            }}
          />
        </label>
      </div>
      <Map bridges={data?.items || []} />
      <p className="muted">
        Map shows the current page of results with usable coordinates. Basemap
        requires internet access.
      </p>
      <section className="panel table-panel">
        <div className="panel-title">
          <h3>{data?.total.toLocaleString() ?? "…"} matching bridges</h3>
          <span className="badge">SAMPLED RECORDS</span>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                {[
                  "Bridge / facility",
                  "State",
                  "Built",
                  "Length",
                  "Material",
                  "Condition",
                  "Source",
                ].map((s) => (
                  <th key={s}>{s}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data?.items.map((b) => (
                <tr key={b.id}>
                  <td>
                    <strong>{b.id}</strong>
                    <small>{b.facility}</small>
                  </td>
                  <td>{b.state}</td>
                  <td>{b.year_built || "—"}</td>
                  <td>{b.length_m ?? "—"} m</td>
                  <td>{b.material}</td>
                  <td>
                    <span className={`badge ${b.condition.toLowerCase()}`}>
                      {b.condition}
                    </span>
                  </td>
                  <td>
                    <button
                      className="text-button"
                      onClick={() =>
                        api<Detail>(`/bridges/${encodeURIComponent(b.id)}`)
                          .then(setDetail)
                          .catch((e) => setDetailError(e.message))
                      }
                    >
                      Details ↗
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pagination">
          <button
            disabled={offset === 0}
            onClick={() => setOffset(Math.max(0, offset - 50))}
          >
            ← Previous
          </button>
          <span>
            {offset + 1}–{Math.min(offset + 50, data?.total || 0)} of{" "}
            {data?.total || 0}
          </span>
          <button
            disabled={offset + 50 >= (data?.total || 0)}
            onClick={() => setOffset(offset + 50)}
          >
            Next →
          </button>
        </div>
      </section>
      {detail && (
        <section className="panel">
          <div className="panel-title">
            <h3>{detail.bridge.id} · Source details</h3>
            <button onClick={() => setDetail(undefined)}>Close</button>
          </div>
          <p>{detail.bridge.location}</p>
          {detail.inspections.map((r, i) => (
            <p key={i}>
              Inspection MMYY: {r.inspection_date} · Deck {r.deck} ·
              Superstructure {r.superstructure} · Substructure {r.substructure}{" "}
              · Culvert {r.culvert}
            </p>
          ))}
          <a href={detail.source.url}>
            Official FHWA archive · {detail.source.vintage} ↗
          </a>
          <p className="hash">SHA-256: {detail.source.sha256}</p>
        </section>
      )}
    </>
  );
}
