import type { Metadata } from "next";
import "./globals.css";
import Shell from "@/components/Shell";
export const metadata: Metadata = {
  title: "Bridge AI · Evidence before inference",
  description: "Bridge document review and FHWA inventory research",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
