import { test, expect } from "@playwright/test";
import path from "node:path";
test("real upload, overlays, zoom, review persistence and exports", async ({
  page,
}) => {
  await page.goto("/analyze");
  await page
    .locator("input[type=file]")
    .setInputFiles(path.resolve("../docs/sample-plan.pdf"));
  await expect(
    page.getByText("3 supported findings", { exact: false }),
  ).toBeVisible();
  await page
    .locator(".finding-focus")
    .filter({ hasText: "Conflicting dimensions" })
    .click();
  await expect(page.locator(".overlay.red")).toBeVisible();
  const before = await page.locator(".overlay.red").evaluate((el) => ({
    left: (el as HTMLElement).style.left,
    top: (el as HTMLElement).style.top,
  }));
  await page.getByRole("button", { name: "Zoom in", exact: true }).click();
  await page.setViewportSize({ width: 1100, height: 850 });
  const after = await page.locator(".overlay.red").evaluate((el) => ({
    left: (el as HTMLElement).style.left,
    top: (el as HTMLElement).style.top,
  }));
  expect(after).toEqual(before);
  const geometry = await page.locator(".overlay.red").evaluate((el) => {
    const r = el.getBoundingClientRect();
    const canvas = el.closest(".page-canvas")!.getBoundingClientRect();
    return {
      actual: [
        (r.x - canvas.x) / canvas.width,
        (r.y - canvas.y) / canvas.height,
        r.width / canvas.width,
        r.height / canvas.height,
      ],
      expected: [
        (el as HTMLElement).style.left,
        (el as HTMLElement).style.top,
        (el as HTMLElement).style.width,
        (el as HTMLElement).style.height,
      ].map((v) => parseFloat(v) / 100),
    };
  });
  geometry.actual.forEach((v, i) =>
    expect(v).toBeCloseTo(geometry.expected[i], 2),
  );
  await page.locator(".finding.red select").selectOption("engineering-review");
  await expect(page.locator(".finding.red select")).toHaveValue(
    "engineering-review",
  );
  await page
    .getByRole("button", { name: "Compare with inventory model" })
    .click();
  await expect(page.getByRole("status")).toContainText(
    "Insufficient information",
  );
  const download = page.waitForEvent("download");
  await page.getByRole("link", { name: "Annotated PDF" }).click();
  expect((await download).suggestedFilename()).toMatch(/annotated.pdf$/);
  await page.getByRole("link", { name: "Reports", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "sample-plan.pdf ↗" }).first(),
  ).toBeVisible();
  await page.getByRole("link", { name: "sample-plan.pdf ↗" }).first().click();
  await expect(page.locator(".finding.red select")).toHaveValue(
    "engineering-review",
  );
});
