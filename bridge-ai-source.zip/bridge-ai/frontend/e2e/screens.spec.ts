import { test, expect } from "@playwright/test";
import path from "node:path";
test("five pages load and produce review screenshots", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1050 });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  for (const [url, heading] of [
    ["/", "Bridge intelligence. Grounded in evidence."],
    ["/bridges", "Bridge database"],
    ["/model", "The model, explained"],
    ["/reports", "Reports"],
    ["/analyze", "Analyze plans"],
  ]) {
    await page.goto(url);
    await expect(
      page.getByRole("heading", { name: heading, exact: true }),
    ).toBeVisible();
    if (url === "/") {
      await expect(page.locator(".stat strong").first()).not.toHaveText("—");
      await page.screenshot({ path: "../docs/overview.png", fullPage: true });
    }
  }
  await page
    .locator("input[type=file]")
    .setInputFiles(path.resolve("../docs/sample-plan.pdf"));
  await expect(page.locator(".finding.red")).toBeVisible();
  await page
    .locator(".finding-focus")
    .filter({ hasText: "Conflicting dimensions" })
    .click();
  await expect(page.locator(".overlay.red")).toBeVisible();
  await expect(page.locator(".react-pdf__Page canvas")).toBeVisible();
  await page.screenshot({ path: "../docs/review.png", fullPage: true });
  expect(errors).toEqual([]);
});
