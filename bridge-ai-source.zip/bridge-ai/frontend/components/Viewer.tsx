"use client";
import { Document, Page, pdfjs } from "react-pdf";
import { useEffect, useRef, useState } from "react";
import { ZoomIn, ZoomOut, ChevronLeft, ChevronRight } from "lucide-react";
import type { Finding } from "@/lib/api";
import { overlayStyle } from "@/lib/overlay";
pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  "pdfjs-dist/build/pdf.worker.min.mjs",
  import.meta.url,
).toString();
export default function Viewer({
  id,
  pages,
  findings,
  selected,
  onSelect,
}: {
  id: string;
  pages: number;
  findings: Finding[];
  selected: string;
  onSelect: (id: string) => void;
}) {
  const [page, setPage] = useState(1),
    [zoom, setZoom] = useState(1),
    [width, setWidth] = useState(650);
  const container = useRef<HTMLDivElement>(null);
  const active = findings.find((f) => f.id === selected);
  useEffect(() => {
    setPage(1);
    setZoom(1);
  }, [id]);
  useEffect(() => {
    const node = container.current;
    if (!node) return;
    const observer = new ResizeObserver((e) =>
      setWidth(Math.max(220, e[0].contentRect.width - 48)),
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (active) {
      setPage(active.page);
      setZoom((z) => Math.max(z, 1.35));
    }
  }, [active]);
  useEffect(() => {
    if (!selected) return;
    const timer = setTimeout(
      () =>
        document.getElementById(`overlay-${selected}`)?.scrollIntoView({
          behavior: "smooth",
          block: "center",
          inline: "center",
        }),
      250,
    );
    return () => clearTimeout(timer);
  }, [selected, page, zoom]);
  return (
    <div className="viewer">
      <div className="viewer-toolbar">
        <div>
          <button
            aria-label="Previous page"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            <ChevronLeft size={17} />
          </button>
          <span>
            Page {page} / {pages}
          </span>
          <button
            aria-label="Next page"
            disabled={page === pages}
            onClick={() => setPage(page + 1)}
          >
            <ChevronRight size={17} />
          </button>
        </div>
        <div>
          <button
            aria-label="Zoom out"
            onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
          >
            <ZoomOut size={17} />
          </button>
          <span>{Math.round(zoom * 100)}%</span>
          <button
            aria-label="Zoom in"
            onClick={() => setZoom(Math.min(3, zoom + 0.25))}
          >
            <ZoomIn size={17} />
          </button>
        </div>
      </div>
      <div className="viewer-scroll" ref={container}>
        <Document
          file={`/api/plans/${id}/file`}
          loading={<p>Rendering document…</p>}
          error={<p role="alert">Could not render this document.</p>}
        >
          <div className="page-canvas" style={{ width: width * zoom }}>
            <Page
              pageNumber={page}
              width={width * zoom}
              renderTextLayer={false}
              renderAnnotationLayer={false}
            />
            <div className="overlay-layer">
              {findings
                .filter((f) => f.page === page && f.status !== "dismissed")
                .map((f) => (
                  <button
                    key={f.id}
                    id={`overlay-${f.id}`}
                    data-testid="finding-overlay"
                    aria-label={`${f.rule}: ${f.evidence}`}
                    className={`overlay ${f.severity} ${selected === f.id ? "selected" : ""}`}
                    style={overlayStyle(f.box)}
                    onClick={() => onSelect(f.id)}
                  >
                    <span>{findings.indexOf(f) + 1}</span>
                  </button>
                ))}
            </div>
          </div>
        </Document>
      </div>
      <div className="viewer-legend">
        <span className="red-dot" /> Document conflict{" "}
        <span className="amber-dot" /> Uncertainty / missing information
      </div>
    </div>
  );
}
