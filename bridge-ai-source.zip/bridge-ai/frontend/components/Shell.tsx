"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  ArrowUpRight,
  FileSearch,
  LayoutDashboard,
  Database,
  BrainCircuit,
  Files,
  ScanLine,
} from "lucide-react";
const links = [
  ["/", "Overview", LayoutDashboard],
  ["/analyze", "Analyze Plans", FileSearch],
  ["/bridges", "Bridge Database", Database],
  ["/model", "AI Model", BrainCircuit],
  ["/reports", "Reports", Files],
] as const;
export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  return (
    <div className="shell">
      <aside className="sidebar">
        <Link href="/" className="brand">
          <span className="brand-icon">
            <Activity size={24} />
          </span>
          bridge<span className="brand-ai">AI</span>
        </Link>
        <div className="workspace-label">ENGINEERING WORKSPACE</div>
        <nav aria-label="Main navigation">
          {links.map(([url, label, Icon]) => (
            <Link
              key={url}
              href={url}
              className={path === url ? "nav active" : "nav"}
            >
              <Icon size={18} />
              {label}
              {path === url && <span className="active-dot" />}
            </Link>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="local-status">
            <span /> LOCAL RESEARCH ENVIRONMENT
          </div>
          <p>Evidence before inference.</p>
          <small>FHWA inventory · 2025 vintage</small>
          <a
            href="https://www.fhwa.dot.gov/bridge/nbi/ascii2025.cfm"
            target="_blank"
            rel="noreferrer"
          >
            View official source <ArrowUpRight size={14} />
          </a>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <span>
            <ScanLine size={16} /> Infrastructure intelligence
          </span>
          <span className="badge purple">RESEARCH PROTOTYPE</span>
        </header>
        <main>{children}</main>
        <footer>
          Bridge AI supports document review. Poor condition is not collapse
          probability. A licensed structural engineer must assess structural
          safety.
        </footer>
      </div>
    </div>
  );
}
