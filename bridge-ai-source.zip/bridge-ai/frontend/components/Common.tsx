export function PageTitle({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}
export function ErrorBox({ error }: { error: string }) {
  return error ? (
    <div role="alert" className="error">
      {error}
    </div>
  ) : null;
}
export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="empty">{children}</div>;
}
export function Downloads({ id }: { id: string }) {
  return (
    <div className="downloads">
      {[
        ["annotated", "Annotated PDF"],
        ["pdf", "Findings PDF"],
        ["csv", "CSV"],
      ].map(([f, label]) => (
        <a
          key={f}
          className="button secondary"
          href={`/api/reports/${id}?format=${f}`}
        >
          {label} ↗
        </a>
      ))}
    </div>
  );
}
