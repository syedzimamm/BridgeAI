"use client";
import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import type { Bridge } from "@/lib/api";
export default function BridgeMap({ bridges }: { bridges: Bridge[] }) {
  return (
    <MapContainer
      center={[39, -97]}
      zoom={4}
      style={{ height: 340, borderRadius: 12 }}
    >
      <TileLayer
        attribution="&copy; OpenStreetMap contributors"
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {bridges
        .filter((b) => b.latitude !== null && b.longitude !== null)
        .map((b) => (
          <CircleMarker
            key={b.id}
            center={[b.latitude!, b.longitude!]}
            radius={5}
            pathOptions={{
              color:
                b.condition === "Poor"
                  ? "#ed6075"
                  : b.condition === "Fair"
                    ? "#dfb968"
                    : "#65b899",
              fillOpacity: 0.8,
            }}
          >
            <Popup>
              <strong>{b.id}</strong>
              <br />
              {b.facility}
              <br />
              {b.condition} · {b.year_built}
            </Popup>
          </CircleMarker>
        ))}
    </MapContainer>
  );
}
