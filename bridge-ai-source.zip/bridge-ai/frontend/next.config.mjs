import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const config = {
  webpack(config) {
    // Avoid nested Webpack runtime-name collisions in PDF.js's unminified build.
    // https://github.com/vercel/next.js/issues/89177
    config.resolve.alias["pdfjs-dist$"] =
      require.resolve("pdfjs-dist/build/pdf.min.mjs");
    return config;
  },
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: `${process.env.BACKEND_URL || "http://127.0.0.1:8000"}/api/:path*`,
      },
    ];
  },
};
export default config;
