import { useCallback, useEffect, useState } from "react";
export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const r = await fetch(`/api${path}`, init);
  if (!r.ok) {
    const body = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error(
      typeof body.detail === "string"
        ? body.detail
        : JSON.stringify(body.detail),
    );
  }
  return r.json();
}
export function useData<T>(path: string) {
  const [data, setData] = useState<T>();
  const [error, setError] = useState("");
  const refresh = useCallback(() => {
    api<T>(path)
      .then((v) => {
        setData(v);
        setError("");
      })
      .catch((e) => setError(e.message));
  }, [path]);
  useEffect(() => {
    let alive = true;
    setData(undefined);
    api<T>(path)
      .then((v) => {
        if (alive) {
          setData(v);
          setError("");
        }
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    return () => {
      alive = false;
    };
  }, [path]);
  return { data, error, refresh };
}
export type Box = [number, number, number, number];
export type Finding = {
  id: string;
  plan_id: string;
  page: number;
  box: Box;
  severity: "red" | "amber";
  category: string;
  rule: string;
  evidence: string;
  explanation: string;
  confidence: number;
  status: string;
  note: string;
};
export type Score = {
  state: string;
  reason: string;
  probability?: number;
  uncertainty?: string;
};
export type Plan = {
  id: string;
  filename: string;
  created_at: string;
  pages: number;
  status: string;
  score: Score | null;
  confirmed_features?: Record<string, string | number | null>;
  extraction: {
    support: string;
    pages: {
      number: number;
      width: number;
      height: number;
      text_chars: number;
    }[];
    candidates: Record<
      string,
      { value: number; evidence: string; page: number }[]
    >;
    annotations: { text: string; page: number }[];
  };
};
export type Bridge = {
  id: string;
  state: string;
  location: string;
  facility: string;
  year_built: number | null;
  material: string;
  condition: string;
  latitude: number | null;
  longitude: number | null;
  length_m: number | null;
  width_m: number | null;
};
export type Evaluation = {
  precision: number;
  recall: number;
  f1: number;
  pr_auc: number;
  brier: number;
  confusion_matrix: number[][];
  calibration: {
    mean_probability: number;
    observed_fraction: number;
    count: number;
  }[];
};
export type Metrics = {
  state?: string;
  winner: string;
  test: Evaluation;
  importance: Record<string, number>;
  splits: Record<string, number>;
  population_prevalence: number;
  validation_comparison: Record<string, Evaluation>;
  limitations: string[];
  split_method: string;
  weighting: string;
  source_provenance: { url: string; sha256: string; vintage: number }[];
};
export type Overview = {
  total: number;
  counts: Record<string, number>;
  recent: Plan[];
};
