import { expect, test } from "vitest";
import { overlayStyle } from "./overlay";
test("normalized overlay coordinates scale without drift", () => {
  const style = overlayStyle([0.1, 0.2, 0.4, 0.5]);
  expect(parseFloat(style.left)).toBe(10);
  expect(parseFloat(style.top)).toBe(20);
  for (const width of [320, 800, 1600]) {
    expect((parseFloat(style.left) * width) / 100).toBeCloseTo(0.1 * width);
    expect((parseFloat(style.width) * width) / 100).toBeCloseTo(0.3 * width);
  }
});
