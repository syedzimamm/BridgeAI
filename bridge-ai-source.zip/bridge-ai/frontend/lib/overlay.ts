import type { Box } from "./api";
export function overlayStyle([x0, y0, x1, y1]: Box) {
  return {
    left: `${x0 * 100}%`,
    top: `${y0 * 100}%`,
    width: `${(x1 - x0) * 100}%`,
    height: `${(y1 - y0) * 100}%`,
  };
}
