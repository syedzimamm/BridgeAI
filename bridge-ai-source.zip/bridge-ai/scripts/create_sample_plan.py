"""Generate a deliberately inconsistent SOFTWARE TEST drawing, not a real bridge."""

from pathlib import Path
import pymupdf as fitz


def make_sample(path):
    doc = fitz.open()
    for i in range(2):
        page = doc.new_page(width=900, height=600)
        page.draw_rect(fitz.Rect(25, 25, 875, 575), color=(0.25, 0.3, 0.4), width=1)
        page.insert_text((45, 55), "BRIDGE AI | SYNTHETIC SOFTWARE TEST FIXTURE", fontsize=18)
        page.insert_text((45, 78), "Not a real bridge. Not for design, construction or model training.", fontsize=11)
        page.insert_text((45, 110), f"SHEET {i + 1} | GENERAL ARRANGEMENT | SCALE 1:100", fontsize=12)
        for x in (120, 400, 720):
            page.draw_rect(fitz.Rect(x, 300, x + 22, 435), color=(0.2, 0.25, 0.35), fill=(0.85, 0.88, 0.91))
        page.draw_rect(fitz.Rect(75, 265, 800, 300), color=(0.2, 0.25, 0.35), fill=(0.9, 0.92, 0.94))
        page.draw_line((85, 240), (790, 240), color=(0.2, 0.25, 0.35))
        for x in (85, 790):
            page.draw_line((x, 230), (x, 250), color=(0.2, 0.25, 0.35))
        page.insert_text((320, 225), f"STRUCTURE LENGTH: {30 if i == 0 else 32} m", fontsize=15)
        page.insert_text((90, 330), "STEEL GIRDER", fontsize=10)
        page.insert_text((420, 460), "CONCRETE PIER", fontsize=10)
        page.insert_text((45, 505), "DECK WIDTH: 10" if i == 0 else "MAXIMUM SPAN: 15 m", fontsize=13)
        page.insert_text(
            (45, 530),
            "SEE DETAIL B7" if i == 0 else "NOTES: Confirm project-specific criteria before review.",
            fontsize=12,
        )
        page.insert_text((650, 555), f"TEST ONLY | REV A | {i + 1}/2", fontsize=10)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)
    doc.close()


if __name__ == "__main__":
    make_sample("docs/sample-plan.pdf")
