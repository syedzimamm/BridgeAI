"""Strict ingestion of official FHWA 2025 comma-delimited state files."""

import argparse
import csv
import hashlib
import io
import json
import random
import urllib.request
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from sqlalchemy import select, func
from backend.db import connect, bridges, inspections, samples, provenance, now

URL = "https://www.fhwa.dot.gov/bridge/nbi/2025Del.zip"
VINTAGE = 2025
FIELDS = {
    "year_built": "YEAR_BUILT_027",
    "length_m": "STRUCTURE_LEN_MT_049",
    "width_m": "DECK_WIDTH_MT_052",
    "max_span_m": "MAX_SPAN_LEN_MT_048",
    "adt": "ADT_029",
    "spans": "MAIN_UNIT_SPANS_045",
    "material": "STRUCTURE_KIND_043A",
    "design": "STRUCTURE_TYPE_043B",
}
RATINGS = dict(
    deck="DECK_COND_058",
    superstructure="SUPERSTRUCTURE_COND_059",
    substructure="SUBSTRUCTURE_COND_060",
    culvert="CULVERT_COND_062",
)
REQUIRED = (
    set(FIELDS.values())
    | set(RATINGS.values())
    | {
        "STATE_CODE_001",
        "STRUCTURE_NUMBER_008",
        "LAT_016",
        "LONG_017",
        "BRIDGE_CONDITION",
        "DATE_OF_INSPECT_090",
        "RECORD_TYPE_005A",
        "BRIDGE_LEN_IND_112",
    }
)


def classify(values):
    # N is not applicable. Blank/invalid components make classification unsupported.
    if any(v not in set("0123456789N") for v in values):
        return None
    nums = [int(v) for v in values if v != "N"]
    if not nums:
        return None
    lowest = min(nums)
    return "Poor" if lowest <= 4 else "Good" if lowest >= 7 else "Fair"


def number(value):
    if not value:
        return None
    result = float(value)
    if result < 0 or result != result:
        raise ValueError(f"Invalid numeric field: {value}")
    return result


def coordinate(value, longitude=False, state=""):
    if not value or not value.isdigit() or int(value) == 0:
        return None
    s = value.zfill(9 if longitude else 8)
    d, m, sec = int(s[:-6]), int(s[-6:-4]), int(s[-4:]) / 100
    if m >= 60 or sec >= 60 or d > (180 if longitude else 90):
        return None
    result = d + m / 60 + sec / 3600
    # NBI omits hemisphere: Guam is E, other reporting jurisdictions W.
    return -result if longitude and state != "66" else result


def rows(archive):
    with zipfile.ZipFile(archive) as z:
        members = sorted(n for n in z.namelist() if n.lower().endswith(".txt"))
        if not members:
            raise ValueError("Archive contains no delimited .txt files")
        for member in members:
            with z.open(member) as raw:
                reader = csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8-sig", newline=""), quotechar="'")
                if not REQUIRED.issubset(reader.fieldnames or []):
                    raise ValueError(
                        f"{member}: missing verified FHWA columns: {REQUIRED - set(reader.fieldnames or [])}"
                    )
                for i, row in enumerate(reader, 2):
                    if None in row or any(v is None for v in row.values()):
                        raise ValueError(f"{member}:{i}: malformed column count")
                    yield {k: v.strip() for k, v in row.items()}, member, i


def ingest(archive, engine, seed=42):
    groups = defaultdict(list)
    seen = set()
    duplicates = set()
    counts = Counter()
    for r, member, line in rows(archive):
        counts["source_rows"] += 1
        if r["RECORD_TYPE_005A"] != "1" or r["BRIDGE_LEN_IND_112"] != "Y":
            counts["excluded_non_highway"] += 1
            continue
        state = r["STATE_CODE_001"].zfill(2)
        ident = f"{state}:{r['STRUCTURE_NUMBER_008']}"
        if ident in seen:
            duplicates.add(ident)
            counts["duplicate_rows"] += 1
            continue
        seen.add(ident)
        rating = {key: r[col] for key, col in RATINGS.items()}
        label = classify(list(rating.values()))
        if label is None:
            counts["unsupported_ratings"] += 1
            continue
        if r["BRIDGE_CONDITION"] != label[0]:
            raise ValueError(f"Official condition mismatch at {member}:{line}")
        b = dict(
            id=ident,
            state=state,
            structure_number=r["STRUCTURE_NUMBER_008"],
            location=r.get("LOCATION_009"),
            facility=r.get("FACILITY_CARRIED_007"),
            latitude=coordinate(r["LAT_016"]),
            longitude=coordinate(r["LONG_017"], True, state),
            condition=label,
        )
        for key, col in FIELDS.items():
            b[key] = r[col] if key in ("material", "design") else number(r[col])
        year = b["year_built"]
        b["year_built"] = int(year) if year and 1700 <= year <= VINTAGE else None
        b["age"] = VINTAGE - b["year_built"] if b["year_built"] else None
        groups[label].append((b, rating, r["DATE_OF_INSPECT_090"].zfill(4), member, line))
    # State and federal submissions can reuse an ID for different structures.
    # Exclude every occurrence of an ambiguous ID, never arbitrarily keep one.
    for label in groups:
        groups[label] = [row for row in groups[label] if row[0]["id"] not in duplicates]
    counts["excluded_ambiguous_ids"] = len(duplicates)
    sizes = {"Poor": 10000, "Fair": 5000, "Good": 5000}
    if any(len(groups[label]) < n for label, n in sizes.items()):
        raise ValueError(f"Insufficient real source records: { {k: len(v) for k, v in groups.items()} }")
    digest = hashlib.sha256(Path(archive).read_bytes()).hexdigest()
    source_id = f"fhwa-2025-{digest[:16]}-seed{seed}"
    details = dict(
        counts,
        ambiguous_ids=sorted(duplicates),
        population={k: len(v) for k, v in groups.items()},
        selected=sizes,
        seed=seed,
        method="Within-condition simple random sampling; sorted IDs then Python Random.sample",
        schema_url="https://www.fhwa.dot.gov/bridge/nbi/format.cfm",
        rules_url="https://www.fhwa.dot.gov/bridge/britab.cfm",
    )
    with engine.begin() as c:
        if c.execute(select(func.count()).select_from(bridges)).scalar():
            existing = c.execute(select(provenance).where(provenance.c.id == source_id)).mappings().first()
            actual = dict(c.execute(select(bridges.c.condition, func.count()).group_by(bridges.c.condition)).all())
            if existing and actual == sizes:
                print(json.dumps({"already_imported": True, **details}, indent=2))
                return details
            raise ValueError("Database already contains a different/incomplete inventory. Use a fresh DATABASE_URL.")
        c.execute(
            provenance.insert().values(
                id=source_id, url=URL, sha256=digest, vintage=VINTAGE, imported_at=now(), details=json.dumps(details)
            )
        )
        rng = random.Random(seed)
        for label, n in sizes.items():
            selected = rng.sample(sorted(groups[label], key=lambda x: x[0]["id"]), n)
            c.execute(bridges.insert(), [dict(b, source_id=source_id) for b, *_ in selected])
            c.execute(
                inspections.insert(),
                [
                    dict(id=b["id"] + ":2025", bridge_id=b["id"], vintage=VINTAGE, inspection_date=date, **rating)
                    for b, rating, date, _, _ in selected
                ],
            )
            c.execute(
                samples.insert(),
                [
                    dict(
                        bridge_id=b["id"],
                        label=label,
                        seed=seed,
                        inclusion_probability=n / len(groups[label]),
                        source_member=member,
                        source_row=line,
                    )
                    for b, _, _, member, line in selected
                ],
            )
        actual = dict(c.execute(select(bridges.c.condition, func.count()).group_by(bridges.c.condition)).all())
        if actual != sizes:
            raise ValueError(f"Imported count validation failed: {actual}")
    print(json.dumps(details, indent=2))
    return details


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--archive", type=Path, default=Path("data/2025Del.zip"))
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    if not args.archive.exists():
        args.archive.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.archive.with_suffix(".download")
        try:
            urllib.request.urlretrieve(URL, temporary)
            if not zipfile.is_zipfile(temporary):
                raise ValueError("FHWA response is not a ZIP archive")
            temporary.replace(args.archive)
        finally:
            temporary.unlink(missing_ok=True)
    ingest(args.archive, connect(), args.seed)


if __name__ == "__main__":
    main()
